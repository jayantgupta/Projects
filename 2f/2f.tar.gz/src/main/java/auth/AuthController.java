/*
	Author : Jayant Gupta
	Date : April 29, 2015
	1. This the Module listening to incoming OTP verification
	requests and accordingly reply back to the user.
	2. Adds a new user's data to the database.

	Key Considerations :-
	1. Where should I store the system key....
	
*/
package auth;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.apache.commons.codec.binary.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Date;

import main.java.com.warrenstrange.googleauth.*;
import org.apache.commons.codec.binary.Base32;

@RestController
public class AuthController{
	
	// Verifies the user's OTP code, can only be accessed by the server.
	@RequestMapping("/verify")
	public static String verifyOTP(@RequestParam(value="OTP", required=true) int OTP, @RequestParam(value="user_id", required=true) String UserID){
		try{
			if(OTP == generateOTP(UserID)){
				return "200";
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return "401";
	}
	
	private static int generateOTP(String UserID)throws Exception{
		// Get key from the DB
		String userEncryptedKey=DBController.getCurrentKey(UserID);
		System.out.println(userEncryptedKey);
		// Decrypt the user key using the system key.
		String userKey = AESDecrypt(userEncryptedKey);
		System.out.println(userKey);
		
		// Generate the OTP code
		GoogleAuthenticator gAuth = new GoogleAuthenticator();
		Base32 codec = new Base32();
		byte[] decodedKey = codec.decode(userKey);
		long tm = new Date().getTime() / 30000;
		int code = gAuth.calculateCode(decodedKey, tm);
		System.out.println(code);
		return code;
	}
	
	@RequestMapping("/addusr")
	public static void addUser(@RequestParam(value="user_id", required=true) String userID, @RequestParam(value="user_key", required=true) String userKey)throws Exception{
		// Encrypt the key.
		String userEncryptedKey = AESEncrypt(userKey);
		// Insert into the database.
		DBController.addNewUser(userID, userEncryptedKey);
		return;
	}
	
	// Encrypts the user key given to it by the server.
	private static String AESEncrypt(String userPlainKey)throws Exception{
		KeyManager KM = new KeyManager();
		byte [] sk_bytes = KM.getSystemKey();
		SecretKey sk = new SecretKeySpec(sk_bytes, "AES");

		Cipher skCipher = Cipher.getInstance("AES");
		skCipher.init(Cipher.ENCRYPT_MODE, sk);

		byte [] encrypted_data = skCipher.doFinal(userPlainKey.getBytes());
		byte [] encoded_encrypted_data = new Base64().encode(encrypted_data);
		String userEncryptedKey = new String(encoded_encrypted_data);
		return userEncryptedKey;
	}
	
	// Decrypts the user encrypted key obtained from the database.
	private static String AESDecrypt(String userEncryptedKey)throws Exception{
		KeyManager KM = new KeyManager();
		byte [] sk_bytes = KM.getSystemKey();
		SecretKey sk = new SecretKeySpec(sk_bytes, "AES");

		Cipher skCipher = Cipher.getInstance("AES");
		skCipher.init(Cipher.DECRYPT_MODE, sk);

		byte [] uEK = userEncryptedKey.getBytes();
		byte [] decoded_key = new Base64().decode(uEK);
		
		byte [] decrypted_data = skCipher.doFinal(decoded_key);
		String user_key =  new String(decrypted_data);
		return user_key;
	}
}
